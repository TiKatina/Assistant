﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assistant
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSuggest_Click(object sender, EventArgs e)
        {
            string direction = cmbDirection.SelectedItem?.ToString() ?? "Не выбрано";
            int score;
            if (!int.TryParse(txtScore.Text, out score))
            {
                txtResult.Text = "Пожалуйста, введи число";
                return;
            }

            string advice;
            if (score >= 80)
            {
                advice = $"Отличный результат! Для направления '{direction}' у тебя хорошие шансы.";
                this.BackColor = Color.LightGreen;
            }
            else if (score >= 60)
            {
                advice = $"Хороший старт. Для направления '{direction}' стоит подтянуть профильные предметы";
                this.BackColor = Color.LightBlue;
            }
            else
            {
                advice = $"Не переживай. Для направления '{direction}' можно начать с курсов и школьных проектов";
                this.BackColor = Color.LightYellow;
            }
            string emoji = score >= 80 
                ? "🎉" 
                : (score >= 60 ? "👍" : "💪");
            advice = $"{emoji} {advice}";
            txtResult.Text = advice; 
        }
    }
}
